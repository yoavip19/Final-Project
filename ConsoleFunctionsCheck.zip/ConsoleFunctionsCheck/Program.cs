﻿//from: YudBet4IroniA@gmail.com
//to: 1000374513@jerschools.org.il
//app pass: qhip imme dcek jgus

using MailKit.Net.Smtp;
using MimeKit;

internal class Program
{
    private static void Main(string[] args)
    {
        
    }
}
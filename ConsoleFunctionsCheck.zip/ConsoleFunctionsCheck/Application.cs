﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;

namespace ConsoleFunctionsCheck
{
    [Table("Application")]
    internal class Application
    {

        [PrimaryKey, AutoIncrement, Column("ApplicationID")]
        public int ApplicationID { get; set; }

        [Column("ApplicationName")]
        public string ApplicationName { get; set; }

        [Column("ApplicationIconURL")]
        public string ApplicationIconURL { get; set; }

        public Application()
        {
        }

        public Application(int applicationID, string applicationName)
        {
            ApplicationID = applicationID;
            ApplicationName = applicationName;
            ApplicationIconURL = ""; //Need to implement API
        }
    }
}

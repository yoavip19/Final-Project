﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

public static class AesHelper
{
    private const int Iterations = 105_173;
    private const int SaltLength = 16;
    private const int KeySizeBits = 256;

    // Encrypts data and outputs Base64 cipher, salt, and IV
    public static string EncryptAES(string dataToEncrypt, string masterPassword, out string saltBase64, out string ivBase64)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(SaltLength);
        byte[] iv;

        using var aes = Aes.Create();
        aes.KeySize = KeySizeBits;

        using var keyDerivation = new Rfc2898DeriveBytes(masterPassword, salt, Iterations, HashAlgorithmName.SHA256);

        aes.Key = keyDerivation.GetBytes(KeySizeBits / 8);
        aes.GenerateIV();
        iv = aes.IV;

        using var encryptor = aes.CreateEncryptor();
        using var ms = new MemoryStream();
        using var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write);
        using var sw = new StreamWriter(cs);

        sw.Write(dataToEncrypt);
        sw.Close();

        byte[] cipherBytes = ms.ToArray();

        // Convert to Base64
        saltBase64 = Convert.ToBase64String(salt);
        ivBase64 = Convert.ToBase64String(iv);
        return Convert.ToBase64String(cipherBytes);
    }

    // Decrypts Base64 ciphertext using the given salt and IV (also Base64)
    public static string DecryptAES(string encryptedBase64, string masterPassword, string saltBase64, string ivBase64)
    {
        byte[] cipherBytes = Convert.FromBase64String(encryptedBase64);
        byte[] salt = Convert.FromBase64String(saltBase64);
        byte[] iv = Convert.FromBase64String(ivBase64);

        using var aes = Aes.Create();
        aes.KeySize = KeySizeBits;

        using var keyDerivation = new Rfc2898DeriveBytes(masterPassword, salt, Iterations, HashAlgorithmName.SHA256);

        aes.Key = keyDerivation.GetBytes(KeySizeBits / 8);
        aes.IV = iv;

        using var decryptor = aes.CreateDecryptor();
        using var ms = new MemoryStream(cipherBytes);
        using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
        using var sr = new StreamReader(cs);

        return sr.ReadToEnd();
    }
    public static void RunTests()
    {
        string masterPassword = "MyMasterPassword123!";
        string websitePassword = "SecretPassword!";

        Console.WriteLine("Original password: " + websitePassword);

        // Encrypt
        string salt, iv;
        string encrypted = AesHelper.EncryptAES(websitePassword, masterPassword, out salt, out iv);

        Console.WriteLine("\n=== ENCRYPTION ===");
        Console.WriteLine("Encrypted Base64: " + encrypted);
        Console.WriteLine("Salt Base64:      " + salt);
        Console.WriteLine("IV Base64:        " + iv);

        // Decrypt
        string decrypted = AesHelper.DecryptAES(encrypted, masterPassword, salt, iv);

        Console.WriteLine("\n=== DECRYPTION ===");
        Console.WriteLine("Decrypted:        " + decrypted);

        // Verify correctness
        if (decrypted == websitePassword)
        {
            Console.WriteLine("\n✅ Test passed: Decrypted text matches original!");
        }
        else
        {
            Console.WriteLine("\n❌ Test failed: Decrypted text does NOT match!");
        }

        // Optional: test with wrong master password
        try
        {
            string wrong = AesHelper.DecryptAES(encrypted, "WrongPassword", salt, iv);
            Console.WriteLine("\n❌ Decryption with wrong password unexpectedly succeeded: " + wrong);
        }
        catch (Exception ex)
        {
            Console.WriteLine("\n✅ Decryption with wrong password failed as expected: " + ex.Message);
        }
    }
}
